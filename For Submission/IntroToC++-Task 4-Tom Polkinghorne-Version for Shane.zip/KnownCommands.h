#pragma once

//list of all available commands

