#pragma once

#ifndef _PRIMARYHEADER_

#define _PRIMARYHEADER_

#ifndef _DEBUG_

//#define _DEBUG_

#endif //	_DEBUG_

#include <iostream>

#include "String.h"
#include "Player.h"
#include "Game.h"
#include "Item.h"
#include "Sink.h"
#include "Lamp.h"
#include "Cat.h"
#include "BoxOfDonuts.h"
#include "DoorKnocker.h"
#include "Bookshelf.h"
#include "Room.h"
#include "Spell.h"



#endif //	_PRIMARYHEADER_