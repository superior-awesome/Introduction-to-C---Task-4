#pragma once
#include "Item.h"
class Bookshelf : public Item
{
	
public:
	Bookshelf();

	void Use();

};

